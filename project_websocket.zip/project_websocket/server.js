const WebSocket = require('ws');

// Tạo server WebSocket lắng nghe trên cổng 8080
const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', (ws) => {
    console.log('Đã kết nối với máy khách!');

    // Khi nhận được tin nhắn từ học sinh
    ws.on('message', (data) => {
        const message = JSON.parse(data);
        console.log('Dữ liệu nhận được:', message);

        // Phát lại dữ liệu tới tất cả các máy khách khác (bao gồm giáo viên)
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify(message)); // Gửi lại dữ liệu cho tất cả kết nối
            }
        });
    });

    // Khi kết nối bị đóng
    ws.on('close', () => {
        console.log('Kết nối đã đóng.');
    });
});

console.log('Server WebSocket đang chạy trên ws://localhost:8080');
